[Nathan Lloyd], [A00847688], [Set C], [Feb. 5, 2014]

This assignment is 99% complete.


------------------------

Question one (Stickman) status:

[complete]

------------------------

Question two (SecondsConvert) status:

[complete]

Though, for some reason the results.html is saying something about an expected EOF.

------------------------

Question three (TempConvert) status:

[complete]

Though, for some reason the results.html is saying something about an expected EOF.

------------------------

Question four (Cylinder) status:

[complete]

Though, for some reason the results.html is saying something about an expected EOF.

------------------------

Question five (BusinessCard) status:

[complete]